from setuptools import setup

setup(name='scope-server',
      version='0.0.1',
      description='Server for the SCope software',
      url='',
      author='M.D.W',
      author_email='mdewaegeneer@gmail.com',
      license='Apache 2.0',
      packages=['scopeserver'],
      zip_safe=False)